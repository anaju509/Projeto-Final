let sugestoes=[
    "Viagens nacionais",
    "Viagens Internacionais",
    "hoteis estrangeiros",
    "hoteis nacionais",
    "roteiros nacionais",
    "africa",
    "asia",
    "europa",
    "america"
]

export {sugestoes};